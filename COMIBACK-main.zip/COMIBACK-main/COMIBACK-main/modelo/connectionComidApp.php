<?php
class DatabaseComidApp
{
    private $host = "10.0.30.10";
    private $dbName = "comidapp";
    private $username = "comidapp";
    private $password = "comidapp12";
    private $connB;

    public function __construct()
    {
        $dsnB = "mysql:host=$this->host;Database=$this->dbName";
        try {
            $this->connB = new PDO($dsnB, $this->username, $this->password);
            $this->connB->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            echo "Error de conexión: " . $e->getMessage();
        }
    }

    public function getConnection()
{
    $this->connB->exec("USE $this->dbName");
    return $this->connB;
}

}

?>
